
import 'package:flutter/material.dart';

void main() => runApp(const PurplePlacePro());

class PurplePlacePro extends StatelessWidget {
  const PurplePlacePro({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: const Text('Purple Place Pro')),
        body: const Center(
          child: Text('Complete project starter structure'),
        ),
      ),
    );
  }
}
