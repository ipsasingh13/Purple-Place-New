// Cake Game Logic
