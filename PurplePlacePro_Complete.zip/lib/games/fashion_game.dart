// Fashion Game Logic
